package com.example.sync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SyncApplicationTests {

	@Test
	void contextLoads() {
	}

}
