package com.example.sync;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.*;

@Component
public class WebSocketHandler extends TextWebSocketHandler {
    // 현재 연결된 세션을 관리하는 Set
    private static Set<WebSocketSession> sessions = Collections.synchronizedSet(new HashSet<>());

    // ObjectMapper는 JSON 처리를 위해 사용
    private ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        sessions.add(session);
        System.out.println("New session connected: " + session.getId());
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        // 클라이언트에서 JSON 형식의 메시지를 보냈으므로 이를 파싱
        Map<String, Object> receivedData = objectMapper.readValue(message.getPayload(), Map.class);

        // 받은 메시지를 다른 세션에 브로드캐스트
        for (WebSocketSession webSocketSession : sessions) {
            if (webSocketSession.isOpen() && !session.getId().equals(webSocketSession.getId())) {
                webSocketSession.sendMessage(new TextMessage(objectMapper.writeValueAsString(receivedData)));
            }
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        sessions.remove(session);
        System.out.println("Session disconnected: " + session.getId());
    }
}
