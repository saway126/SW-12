package com.example.sync;

import java.util.List;

public class WebSocketMessage {
    private String type; // message 또는 user-update
    private String sender; // 메시지를 보낸 사용자 이름
    private String content; // 메시지 내용
    private List<String> activeUsers; // 접속 중인 사용자 목록

    // 기본 생성자, getter, setter 추가
    public WebSocketMessage() {}

    public WebSocketMessage(String type, String sender, String content, List<String> activeUsers) {
        this.type = type;
        this.sender = sender;
        this.content = content;
        this.activeUsers = activeUsers;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public List<String> getActiveUsers() {
        return activeUsers;
    }

    public void setActiveUsers(List<String> activeUsers) {
        this.activeUsers = activeUsers;
    }
}