package com.example.websocket;

import com.example.websocket.model.ChatMessage;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Slf4j
@RequiredArgsConstructor
@Component
public class WebSocketHandler extends TextWebSocketHandler {
    private final Set<WebSocketSession> sessions = new HashSet<>();
    private final Map<String, WebSocketSession> users = new HashMap<>();
    private final ObjectMapper objectMapper;

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        sessions.add(session);
        log.info("{} 클라이언트가 접속했습니다.", session.getId());
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        log.info("받은 메시지 : {}", message);

        ChatMessage chatMessage = objectMapper.readValue(message.getPayload(), ChatMessage.class);
        if (chatMessage.getType() == ChatMessage.MessageType.ENTER) {
            users.put(chatMessage.getSender(), session);
            for (WebSocketSession s : sessions) {
                s.sendMessage(new TextMessage(objectMapper.writeValueAsString(chatMessage)));
            }
        } else if(chatMessage.getType() == ChatMessage.MessageType.TALK) {
            for (WebSocketSession s : sessions) {
                if(users.get(chatMessage.getSender()).equals(s)) {
                    continue;
                }
                s.sendMessage(new TextMessage(objectMapper.writeValueAsString(chatMessage)));
            }
        }

    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        sessions.remove(session);
        log.info("{} 클라이언트가 연결을 끊었습니다.", session.getId());
    }
}
