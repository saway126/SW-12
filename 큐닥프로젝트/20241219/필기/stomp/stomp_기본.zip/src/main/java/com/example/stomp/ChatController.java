package com.example.stomp;

import com.example.stomp.model.ChatMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;

import java.util.HashSet;
import java.util.Set;

@Controller
@RequiredArgsConstructor
public class ChatController {
    private final Set<String> activeUsers = new HashSet<>();
    private final ObjectMapper objectMapper = new ObjectMapper();

    private final SimpMessagingTemplate simpMessagingTemplate;

    @MessageMapping("/chat.addUser")
    @SendTo("/topic/public")
    public ChatMessage addUser(ChatMessage chatMessage, SimpMessageHeaderAccessor headerAccessor) throws JsonProcessingException {
        activeUsers.add(chatMessage.getSender());
        // 웹소켓 세션에 사용자 이름 추가

        chatMessage.setMessage(objectMapper.writeValueAsString(activeUsers));
        headerAccessor.getSessionAttributes().put("username", chatMessage.getSender());
        return chatMessage;
    }

    @MessageMapping("/chat.sendMessage")
    @SendTo("/topic/public")
    public ChatMessage sendMessage(ChatMessage chatMessage) {
        return chatMessage; // 보낸 메시지를 그대로 반환하여 구독자들에게 전송
    }

    // 아직 안됨
//    @MessageMapping("/chat.sendMessage")
//    public void sendMessage(ChatMessage chatMessage) {
//
//        simpMessagingTemplate.convertAndSendToUser(chatMessage.getReceiver(), "/topic/public", chatMessage);
//    }
}
