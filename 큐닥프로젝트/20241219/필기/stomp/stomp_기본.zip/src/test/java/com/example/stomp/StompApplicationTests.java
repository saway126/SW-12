package com.example.stomp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StompApplicationTests {

    @Test
    void contextLoads() {
    }

}
